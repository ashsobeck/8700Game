# 8700Game

Game for CPSC 8700

# Presentation

Our presentation for class located [here](./8700SnakeGamePres.pdf) 

# Install Requirements

*You ***must*** have Python 3.10 to run this game*

Otherwise, you will get an error. 

If you are on Windows, you need an Xserver to be able to run this game as well. Xlaunch is a good one that will work out of the box. 

When you launch Xlaunch, you will need to select `Disable access control` in order for the game to automatically launch from the terminal.

Use Following command to install requirements:

```
pip install -r requirements.txt
```

# Run

Run -  ```python main.py``` or ```python3 main.py```
